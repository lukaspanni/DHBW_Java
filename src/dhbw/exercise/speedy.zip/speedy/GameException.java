package dhbw.exercise.speedy;

@SuppressWarnings("serial")
public class GameException extends Exception {
	public GameException(String message) {
		super(message);
	}
}
